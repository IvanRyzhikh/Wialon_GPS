#pragma once

namespace law::fd {
    class FileDescriptor;
}
