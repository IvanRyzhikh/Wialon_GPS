#pragma once

#include <chrono>

namespace Utils {
    std::chrono::milliseconds getCurrentTimeInMs();
}