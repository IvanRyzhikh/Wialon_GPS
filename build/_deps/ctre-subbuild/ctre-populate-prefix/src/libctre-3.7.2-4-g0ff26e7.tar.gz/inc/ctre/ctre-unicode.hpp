#ifndef CTRE_V2__CTRE_UNICODE__HPP
#define CTRE_V2__CTRE_UNICODE__HPP

#include "ctre.hpp"
#include "unicode-db.hpp"

#endif
